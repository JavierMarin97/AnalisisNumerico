spline <-function(x,y,z,longitud){
  require(akima)
  require(rgl)
  spline_interpolated <- interp(x, y, z,
                                xo=seq(min(x), max(x), length = longitud),
                                yo=seq(min(y), max(y), length = longitud),
                                linear = FALSE, extrap = TRUE)

  x0 <- spline_interpolated$x
  y0 <- spline_interpolated$y
  z0 <- spline_interpolated$z

  persp3d(x0, y0, z0, col = "blue")
}

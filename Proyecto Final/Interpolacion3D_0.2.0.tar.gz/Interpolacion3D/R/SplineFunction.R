spline <-function(x,y,z,longitud){
  require(akima)
  require(rgl)
  sumTeo=0
  sumExp=0
  error=0
  spline_interpolated = interp(x, y, z,
                                xo=seq(min(x), max(x), length = longitud),
                                yo=seq(min(y), max(y), length = longitud),
                                linear = FALSE, extrap = TRUE)

  x.si = spline_interpolated$x
  y.si = spline_interpolated$y
  z.si = spline_interpolated$z
  print(z.si)

  for(i in 1:length(z)){
    sumTeo=z[i]+sumTeo
    sumExp=(z.si[i,i])+sumExp
  }
  error=abs(sumTeo-sumExp)
  paste("el error es de: ",round(error*0.0001,5))
  persp3d(x.si, y.si, z.si, col = "blue")
}
